# Многостраничный сайт

## Предпросмотр проекта
Для просмотра собранного варианта, необходимо перейти по [ссылке](https://seasle.github.io/multipage-website/).

## Ветки
Ветка [`master`](https://github.com/Seasle/multipage-website/tree/master) содержит исходный код проекта.

Ветка [`gh-pages`](https://github.com/Seasle/multipage-website/tree/gh-pages) содержит собранный вариант проекта.
